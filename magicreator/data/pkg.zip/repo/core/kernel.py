#/usr/bin/env python3
''' KERNEL MODULE '''

# ---imports---


# ---Module regime consts and variables---


# ---Classes and Functions---


# ---Unit test---
if __name__ == '__main__':
    pass
